// ============================================================
// ZA Backend — fetch-news.js
// Vercel Cron: runs every 30 minutes
// جلب الأخبار + معالجة + ترجمة + حفظ في Supabase
// ============================================================

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL  = process.env.SUPABASE_URL;
const SUPABASE_KEY  = process.env.SUPABASE_SERVICE_KEY;
const ND_KEY        = process.env.NEWSDATA_KEY || 'pub_b052f1ec148241688b243f4017e9f0e4';

// ── RSS Sources ──────────────────────────────────────────────
const RSS_FEEDS = [
  { n:'FXStreet',     u:'https://www.fxstreet.com/rss/news'                          },
  { n:'FXStreet',     u:'https://www.fxstreet.com/rss/analysis'                      },
  { n:'FXStreet',     u:'https://www.fxstreet.com/rss/crypto'                        },
  { n:'FXStreet',     u:'https://www.fxstreet.com/rss/stocks'                        },
  { n:'DailyFX',      u:'https://www.dailyfx.com/feeds/all'                          },
  { n:'Myfxbook',     u:'https://www.myfxbook.com/rss/latest-forex-news'             },
  { n:'MarketWatch',  u:'https://feeds.content.dowjones.io/public/rss/mw_realtimeheadlines' },
  { n:'CNBC',         u:'https://www.cnbc.com/id/100003114/device/rss/rss.html'      },
  { n:'CNBC',         u:'https://www.cnbc.com/id/10000664/device/rss/rss.html'       },
  { n:'Reuters',      u:'https://feeds.reuters.com/reuters/businessNews'             },
  { n:'Investing.com',u:'https://www.investing.com/rss/news_1.rss'                   },
  { n:'Investing.com',u:'https://www.investing.com/rss/news_25.rss'                  },
];

// ── Helpers ──────────────────────────────────────────────────
function guessCategory(t) {
  const s = (t||'').toLowerCase();
  if (/gold|xau|silver/.test(s))                    return 'gold';
  if (/bitcoin|btc|crypto|ethereum|eth/.test(s))    return 'crypto';
  if (/oil|crude|brent|wti|opec/.test(s))           return 'oil';
  if (/stock|nasdaq|s&p|dow|equity|shares/.test(s)) return 'stocks';
  if (/fed|ecb|rate|inflation|gdp|cpi|fomc/.test(s))return 'macro';
  return 'forex';
}

function guessSentiment(t) {
  const s = (t||'').toLowerCase();
  if (/rises|gains|\bup\b|bullish|surge|rally|strong|beat/.test(s)) return 'pos';
  if (/falls|drops|\bdown\b|bearish|plunge|weak|miss|slump/.test(s)) return 'neg';
  return 'neu';
}

function parseXML(xmlStr) {
  const items = [];
  const itemRegex = /<item[^>]*>([\s\S]*?)<\/item>/gi;
  let match;
  while ((match = itemRegex.exec(xmlStr)) !== null) {
    const block = match[1];
    const get = (tag) => {
      const m = block.match(new RegExp(`<${tag}[^>]*><!\\[CDATA\\[([\\s\\S]*?)\\]\\]><\\/${tag}>|<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i'));
      return m ? (m[1]||m[2]||'').trim() : '';
    };
    const linkMatch = block.match(/<link[^>]*>([^<]*)<\/link>|<link[^>]*\/?>([^<]*)/i);
    items.push({
      title:   get('title'),
      link:    linkMatch ? (linkMatch[1]||linkMatch[2]||'').trim() : '',
      pubDate: get('pubDate'),
      description: get('description').replace(/<[^>]+>/g,'').slice(0,200),
    });
  }
  return items;
}

// ── Translate via MyMemory ───────────────────────────────────
async function translateToAr(text) {
  if (!text || /[\u0600-\u06FF]/.test(text)) return text;
  try {
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text.slice(0,400))}&langpair=en|ar`;
    const r = await fetch(url);
    const d = await r.json();
    return d?.responseData?.translatedText || text;
  } catch { return text; }
}

// ── Fetch RSS ────────────────────────────────────────────────
async function fetchRSS(feed) {
  try {
    const r = await fetch(feed.u, {
      headers: { 'User-Agent': 'Mozilla/5.0 ZA-News-Bot/1.0' },
      signal: AbortSignal.timeout(8000),
    });
    const xml = await r.text();
    return parseXML(xml).slice(0, 20).map((item, i) => ({
      ext_id:    `${feed.n}-${i}-${item.pubDate}`,
      title_en:  item.title,
      title_ar:  '',
      link:      item.link,
      summary:   item.description,
      source:    feed.n,
      category:  guessCategory(item.title),
      sentiment: guessSentiment(item.title),
      pub_date:  item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
    }));
  } catch (e) {
    console.error(`RSS failed: ${feed.n}`, e.message);
    return [];
  }
}

// ── Fetch NewsData.io ────────────────────────────────────────
async function fetchNewsData() {
  try {
    const url = `https://newsdata.io/api/1/latest?apikey=${ND_KEY}`
      + `&q=${encodeURIComponent('ذهب اسهم دولار عملات اخبار forex gold')}`
      + `&language=ar,en`
      + `&excludecountry=ca,cn,jp`
      + `&excludecategory=politics,technology,entertainment,health,science,sports`
      + `&prioritydomain=medium`
      + `&removeduplicate=1`
      + `&sort=pubdate`;

    const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
    const d = await r.json();

    if (!d.results) { console.error('NewsData error:', d); return []; }

    return d.results.map((a, i) => ({
      ext_id:    `nd-${a.article_id || i}-${a.pubDate}`,
      title_en:  /[\u0600-\u06FF]/.test(a.title||'') ? '' : (a.title||''),
      title_ar:  /[\u0600-\u06FF]/.test(a.title||'') ? (a.title||'') : '',
      link:      a.link || '#',
      summary:   (a.description||'').slice(0, 200),
      source:    a.source_name || a.source_id || 'NewsData',
      category:  guessCategory(a.title),
      sentiment: guessSentiment(a.title),
      pub_date:  a.pubDate ? new Date(a.pubDate).toISOString() : new Date().toISOString(),
    }));
  } catch (e) {
    console.error('NewsData failed:', e.message);
    return [];
  }
}

// ── Dedup ────────────────────────────────────────────────────
function dedup(items) {
  const seen = new Set();
  return items.filter(n => {
    if (!n.title_en && !n.title_ar) return false;
    const title = (n.title_en || n.title_ar || '');
    if (title.length < 8) return false;
    const k = title.toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]/g,'').slice(0, 45);
    if (seen.has(k)) return false;
    seen.add(k); return true;
  });
}

// ── Main Handler ─────────────────────────────────────────────
export default async function handler(req, res) {
  // Security: only allow Vercel cron or manual trigger with secret
  const authHeader = req.headers.authorization;
  const cronSecret = process.env.CRON_SECRET;
  if (cronSecret && authHeader !== `Bearer ${cronSecret}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  console.log('🚀 ZA fetch-news started:', new Date().toISOString());

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

    // 1. Fetch all sources in parallel
    console.log('📡 Fetching RSS feeds...');
    const rssResults = await Promise.allSettled(RSS_FEEDS.map(fetchRSS));
    let items = [];
    rssResults.forEach(r => { if (r.status === 'fulfilled') items = items.concat(r.value); });
    console.log(`✅ RSS: ${items.length} items`);

    console.log('📡 Fetching NewsData.io...');
    const ndItems = await fetchNewsData();
    items = items.concat(ndItems);
    console.log(`✅ NewsData: ${ndItems.length} items`);

    // 2. Dedup
    items = dedup(items);
    console.log(`🔧 After dedup: ${items.length} items`);

    // 3. Translate English titles in batches of 10
    console.log('🌐 Translating...');
    const toTranslate = items.filter(n => n.title_en && !n.title_ar);
    for (let i = 0; i < toTranslate.length; i += 10) {
      const batch = toTranslate.slice(i, i + 10);
      await Promise.all(batch.map(async n => {
        n.title_ar = await translateToAr(n.title_en);
      }));
    }
    console.log(`✅ Translated ${toTranslate.length} titles`);

    // 4. Upsert to Supabase
    console.log('💾 Saving to Supabase...');
    const rows = items.map(n => ({
      ext_id:    n.ext_id,
      title_en:  n.title_en || '',
      title_ar:  n.title_ar || n.title_en || '',
      link:      n.link,
      summary:   n.summary || '',
      source:    n.source,
      category:  n.category,
      sentiment: n.sentiment,
      pub_date:  n.pub_date,
      fetched_at: new Date().toISOString(),
    }));

    const { error } = await supabase
      .from('news')
      .upsert(rows, { onConflict: 'ext_id', ignoreDuplicates: true });

    if (error) throw error;

    // 5. Clean old news (keep last 7 days)
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    await supabase.from('news').delete().lt('pub_date', weekAgo);

    console.log(`✅ Done! Saved ${rows.length} articles`);
    return res.status(200).json({ success: true, count: rows.length, timestamp: new Date().toISOString() });

  } catch (e) {
    console.error('❌ Error:', e);
    return res.status(500).json({ error: e.message });
  }
}
