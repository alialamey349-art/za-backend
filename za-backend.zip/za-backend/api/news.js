// ============================================================
// ZA Backend — api/news.js
// GET /api/news?source=FXStreet&category=gold&q=dollar&page=1
// يرجع الأخبار من Supabase للموقع
// ============================================================

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY;

export default async function handler(req, res) {
  // CORS — allow any origin (since ZA is a static HTML file)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    const { source, category, q, page = 1, limit = 50 } = req.query;

    let query = supabase
      .from('news')
      .select('id, title_ar, title_en, link, summary, source, category, sentiment, pub_date, fetched_at')
      .order('pub_date', { ascending: false })
      .range((page - 1) * limit, page * limit - 1);

    if (source && source !== 'all') query = query.eq('source', source);
    if (category && category !== 'all') query = query.eq('category', category);
    if (q) query = query.or(`title_ar.ilike.%${q}%,title_en.ilike.%${q}%`);

    const { data, error, count } = await query;
    if (error) throw error;

    // Count per source for sidebar
    const { data: sourceCounts } = await supabase
      .from('news')
      .select('source')
      .order('source');

    const counts = {};
    (sourceCounts || []).forEach(r => {
      counts[r.source] = (counts[r.source] || 0) + 1;
    });

    return res.status(200).json({
      success: true,
      total: data?.length || 0,
      articles: data || [],
      sourceCounts: counts,
      timestamp: new Date().toISOString(),
    });

  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: e.message });
  }
}
