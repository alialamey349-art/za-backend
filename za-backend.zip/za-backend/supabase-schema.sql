-- ============================================================
-- ZA News — Supabase Schema
-- انسخ هذا الكود في Supabase → SQL Editor → Run
-- ============================================================

-- جدول الأخبار
CREATE TABLE IF NOT EXISTS news (
  id          BIGSERIAL PRIMARY KEY,
  ext_id      TEXT UNIQUE NOT NULL,
  title_ar    TEXT NOT NULL DEFAULT '',
  title_en    TEXT NOT NULL DEFAULT '',
  link        TEXT NOT NULL DEFAULT '#',
  summary     TEXT DEFAULT '',
  source      TEXT NOT NULL,
  category    TEXT NOT NULL DEFAULT 'forex',
  sentiment   TEXT NOT NULL DEFAULT 'neu',
  pub_date    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fetched_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index للبحث السريع
CREATE INDEX IF NOT EXISTS idx_news_pub_date  ON news (pub_date DESC);
CREATE INDEX IF NOT EXISTS idx_news_source    ON news (source);
CREATE INDEX IF NOT EXISTS idx_news_category  ON news (category);
CREATE INDEX IF NOT EXISTS idx_news_search    ON news USING gin(to_tsvector('simple', title_ar || ' ' || title_en));

-- السماح للـ Frontend بالقراءة (anon key)
ALTER TABLE news ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read" ON news
  FOR SELECT USING (true);

-- السماح للـ Backend بالكتابة (service key فقط)
CREATE POLICY "Allow service write" ON news
  FOR ALL USING (true);
