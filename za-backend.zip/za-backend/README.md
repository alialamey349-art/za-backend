# 🚀 دليل إعداد ZA Backend
## Vercel + Supabase — خطوة بخطوة

---

## الخطوة 1: إعداد Supabase (قاعدة البيانات)

1. اذهب إلى https://supabase.com وسجّل مجاناً
2. اضغط **New Project** → اختر اسماً (مثلاً: za-news)
3. بعد إنشاء المشروع، اذهب إلى:
   **SQL Editor** → **New Query** → انسخ محتوى ملف `supabase-schema.sql` والصقه → اضغط **Run**
4. احفظ هذه المعلومات من **Settings → API**:
   - `Project URL` → مثلاً: https://xxxx.supabase.co
   - `anon public key`
   - `service_role key` (سري، لا تشاركه)

---

## الخطوة 2: رفع الكود على Vercel

1. اذهب إلى https://github.com وأنشئ repository جديد اسمه `za-backend`
2. ارفع هذه الملفات:
   - `api/fetch-news.js`
   - `api/news.js`
   - `vercel.json`
   - `package.json`
3. اذهب إلى https://vercel.com وسجّل دخول
4. اضغط **Add New Project** → اختر الـ repository
5. اضغط **Deploy**

---

## الخطوة 3: إضافة Environment Variables في Vercel

في Vercel → Settings → Environment Variables، أضف:

| الاسم | القيمة |
|-------|--------|
| `SUPABASE_URL` | https://xxxx.supabase.co |
| `SUPABASE_ANON_KEY` | anon key من Supabase |
| `SUPABASE_SERVICE_KEY` | service_role key من Supabase |
| `NEWSDATA_KEY` | pub_b052f1ec148241688b243f4017e9f0e4 |
| `CRON_SECRET` | اخترأي كلمة سرية (مثلاً: za-secret-2026) |

---

## الخطوة 4: تشغيل أول جلب للأخبار

بعد الـ Deploy، افتح هذا الرابط في متصفحك:
```
https://YOUR-PROJECT.vercel.app/api/fetch-news
```
سترى: `{"success":true,"count":150,...}`

---

## الخطوة 5: تحديث موقع ZA

في ملف `za-news.html`، غيّر هذا السطر:
```javascript
const API_BASE = 'https://YOUR-PROJECT.vercel.app';
```
إلى رابط مشروعك الفعلي على Vercel.

---

## ✅ النتيجة

- كل 30 دقيقة: Vercel يجلب الأخبار تلقائياً → يترجم → يحفظ في Supabase
- موقع ZA يقرأ من Supabase مباشرة بسرعة فائقة ⚡
- لا CORS، لا مشاكل، لا API Keys في المتصفح
